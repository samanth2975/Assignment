package com.test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.exception.InvalidConsumerException;
import com.model.Consumer;
import com.util.CreditScoreReport;

public class CreditScoreReportTest
{
	private static  CreditScoreReport csrObj;
	
	@BeforeAll
	
	public static void setUp() throws Exception 
	{
	csrObj= new CreditScoreReport();
	
		//Create few  objects for Consumer class and add to a list.
		//Set that list to the consumerList, using the setConsumerList method in CreditScoreReport class
	
	    
	}
	
	
	// Test totalConsumerCountForEachCreditScoreRange method
	public void test11TotalConsumerCountForEachCreditScoreRange()
	{	 	  	  	 		  	     	      	 	
		// Fill the code here
	}
	// Test totalConsumerCountForEachCreditScoreRange method when the list is empty
	public void test12TotalConsumerCountForEachCreditScoreRangeForEmptyList()
	{
		// Fill the code here
	
	}
	//Test the viewConsumerReportBasedOnCreditScore method when creditScore is between 800 to 900
	public void test13ViewConsumerReportBasedOnCreditScoreWhenExcellent()
	{
		// Fill the code here
	}
	//Test the viewConsumerReportBasedOnCreditScore method when creditScore is between 600 to 799
	public void test14ViewConsumerReportBasedOnCreditScoreWhenGood()
	{
		// Fill the code here
	}
	//Test the viewConsumerReportBasedOnCreditScore method when creditScore is between 500 to 599
	public void test15ViewConsumerReportBasedOnCreditScoreWhenFair()
	{
		// Fill the code here
	}
	//Test the viewConsumerReportBasedOnCreditScore method when creditScore is between 300 to 499
	public void test16ViewConsumerReportBasedOnCreditScoreWhenPoor()
	{
		// Fill the code here
	}
	//Test the viewConsumerReportBasedOnCreditScore method For EmptyList
	public void test17ViewConsumerReportBasedOnCreditScoreForEmptyList()
	{
		// Fill the code here
	}
}
	 	  	  	 		  	     	      	 	